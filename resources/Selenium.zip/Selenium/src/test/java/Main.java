public class Main {

    public static void main(String[] args) {
        LoginTest login = new LoginTest();
        login.loginWithValidePass();
//        login.loginWithInValidePass();
        MenuTest search = new MenuTest();
        search.searchForChealseaTee();
        search.povestiCopii();
    }
}
